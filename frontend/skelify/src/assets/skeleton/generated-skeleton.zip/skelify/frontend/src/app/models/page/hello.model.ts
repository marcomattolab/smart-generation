export interface IHello {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
}
