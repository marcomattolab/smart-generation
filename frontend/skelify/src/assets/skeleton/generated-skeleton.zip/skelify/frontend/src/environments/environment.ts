export const environment = {
  production: false,
  clientId: 'skelify',
  apiUrl: "http://localhost:8082/api/v1",
  authority: 'http://localhost:8444/realms/skelify'
};
