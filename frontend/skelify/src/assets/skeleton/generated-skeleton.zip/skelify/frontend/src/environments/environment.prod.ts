export const environment = {
  production: true,
  clientId: 'skelify',
  apiUrl:  "/api/v1",
  authority: 'https://keycloak-prj-elca-skelify.apps.okd.svc.elca.ch/realms/skelify'
};
