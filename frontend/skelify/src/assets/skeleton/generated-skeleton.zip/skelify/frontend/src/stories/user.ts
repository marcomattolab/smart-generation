export interface User {
  name: string;
}
