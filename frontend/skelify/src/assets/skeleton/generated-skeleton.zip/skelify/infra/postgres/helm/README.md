# Deploy PostgreSQL POD via Helm Chart

This guide describes how to deploy a **PostgreSQL** POD on OKD using the Bitnami Helm chart.

---

## Prerequisites

- Target namespace created (e.g. `prj-elca-scn` in this example)
- Helm v3+ installed
  - ```bash
    curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
- Add Bitnami charts repo
  - ```bash
    helm repo add bitnami https://charts.bitnami.com/bitnami
    helm repo update
- Access to the cluster with `oc` (copy login command from OKD).
- Configuration file:
    - `postgres-values.yml` → PostgreSQL helm chart customization

---

## Deploy PostgreSQL

1. Make sure you are in the folder containing `postgres-values.yml`.
2. Deploy PostgreSQL with Helm:

```bash
helm install postgres bitnami/postgresql -f postgres-values.yml -n prj-elca-scn
```

---
## Connect to DB 
* Use ELCA OKD External IP (`10.10.38.76`)
* **NodePort** defined just for dev environment to access the DB with a db-client
* Use credentials defined in **_postgres-values.yml_**

`10.10.38.76:32345/skelify
`
