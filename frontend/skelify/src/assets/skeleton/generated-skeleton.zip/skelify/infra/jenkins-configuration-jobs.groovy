// Minimal multibranch pipeline for the BACKEND CI
dsl.bitbucketSourcesMultibranchPipeline(
        context: this,
        name: 'IT-Elcathon2025-SmartGenerator-Backend-CI',
        description: 'Backend - CI | IT-Elcathon2025-SmartGenerator',
        repositoryName: 'IT-Elcathon2025-SmartGenerator',
        scriptPath: 'skelify/infra/backend/devops/Jenkinsfile',
        suppressAutomaticTriggerBranchRegex: '.*',
        suppressAutomaticTriggerStrategy: 'INDEXING',
        traits: [
                discoverTags: true,
                discoverBranches: true,
                discoverPullRequests: false
        ],
        strategies: [
                pullRequests: false,
                skipInitialBuildOnFirstBranchIndexing: true
        ]
)

// BACKEND deploy
dsl.gitPipeline(
        context: this,
        name: 'IT-Elcathon2025-SmartGenerator-Backend-CD',
        description: 'Backend - CD | IT-Elcathon2025-SmartGenerator',
        scriptPath: 'skelify/infra/backend/devops/Jenkinsfile.deploy',
        git: [
                branches: ['$BRANCH'],
                remotes: [
                        [
                                name: 'origin',
                                repoPath: 'ELCA-SCN/IT-Elcathon2025-SmartGenerator'
                        ],
                ],
        ],
        parameters: [
                git: [
                        [
                                name: 'BRANCH',
                                description: 'The branch of the backend to deploy',
                                repoPath: 'ELCA-SCN/IT-Elcathon2025-SmartGenerator',
                                type: 'PT_BRANCH',
                                defaultValue: 'origin/main',
                                branchFilter: '.*',
                        ],
                ],
        ],
)


// Minimal multibranch pipeline for the FRONTEND CI
dsl.bitbucketSourcesMultibranchPipeline(
        context: this,
        name: 'IT-Elcathon2025-SmartGenerator-Frontend-CI',
        description: 'Frontend - CI | IT-Elcathon2025-SmartGenerator',
        repositoryName: 'IT-Elcathon2025-SmartGenerator',
        scriptPath: 'skelify/infra/frontend/devops/Jenkinsfile',
        suppressAutomaticTriggerBranchRegex: '.*',
        suppressAutomaticTriggerStrategy: 'INDEXING',
        traits: [
                discoverTags: true,
                discoverBranches: true,
                discoverPullRequests: false
        ],
        strategies: [
                pullRequests: false,
                skipInitialBuildOnFirstBranchIndexing: true
        ]
)

// FRONTEND deploy
dsl.gitPipeline(
        context: this,
        name: 'IT-Elcathon2025-SmartGenerator-Frontend-CD',
        description: 'Frontend - CD | IT-Elcathon2025-SmartGenerator',
        scriptPath: 'skelify/infra/frontend/devops/Jenkinsfile.deploy',
        git: [
                branches: ['$BRANCH'],
                remotes: [
                        [
                                name: 'origin',
                                repoPath: 'ELCA-SCN/IT-Elcathon2025-SmartGenerator'
                        ],
                ],
        ],
        parameters: [
                git: [
                        [
                                name: 'BRANCH',
                                description: 'The branch of the frontend to deploy',
                                repoPath: 'ELCA-SCN/IT-Elcathon2025-SmartGenerator',
                                type: 'PT_BRANCH',
                                defaultValue: 'origin/main',
                                branchFilter: '.*',
                        ],
                ],
        ],
)
