# Deploy Keycloak POD via Helm Chart

This guide describes how to deploy a **Keycloak** POD on OKD using the Bitnami Helm chart.

---

## Prerequisites

- Target namespace created (e.g. `prj-elca-scn` in this example)
- Helm v3+ installed
    - ```bash
      curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
- Add Bitnami charts repo
    - ```bash
      helm repo add bitnami https://charts.bitnami.com/bitnami
      helm repo update
- **A running PostgreSQL instance** (another POD available with postgres in the same cluster).
- Configuration file:
    - `keycloak-values.yml` → Keycloak helm chart customization

---

## Deploy Keycloak

1. Make sure you are in the folder containing `keycloak-values.yml`
2. Deploy Keycloak with Helm:

```bash
helm install keycloak bitnami/keycloak -f keycloak-values.yml -n prj-elca-scn
```

---
## Access Keycloak Dashboard
With OKD Ingress hostname defined 

Note: Chrome ofter redirects automatically to https

https://keycloak-prj-elca-skelify.apps.okd.svc.elca.ch/
