DELETE FROM ORDERS_PRODUCTS WHERE 1 = 1;
DELETE FROM ORDERS WHERE 1 = 1;
DELETE FROM ADDRESSES WHERE 1 = 1;
DELETE FROM CUSTOMERS WHERE 1 = 1;
DELETE FROM PRODUCTS WHERE 1 = 1;

INSERT INTO PRODUCTS (id, name, price) VALUES (1, 'Laptop', 1200.0);
INSERT INTO PRODUCTS (id, name, price) VALUES (2, 'Mouse', 25.0);
INSERT INTO PRODUCTS (id, name, price) VALUES (3, 'Keyboard', 45.0);
INSERT INTO PRODUCTS (id, name, price) VALUES (4, 'Monitor', 250.0);

INSERT INTO CUSTOMERS (id, name, surname, email) VALUES (1, 'Ted', 'Mosby', 'ted.mosby@gmail.com');
INSERT INTO CUSTOMERS (id, name, surname, email) VALUES (2, 'Sheldon', 'Cooper', 'sheldon.cooper@gmail.com');
INSERT INTO CUSTOMERS (id, name, surname, email) VALUES (3, 'Harvey', 'Specter', 'harvey.specter@gmail.com');
INSERT INTO CUSTOMERS (id, name, surname, email) VALUES (4, 'Walter', 'White', 'walter.white@gmail.com');

INSERT INTO ADDRESSES (id, country, city, street_name, zip_code) VALUES (1, 'USA', 'New York', 'Second Street 19', 'US123');
INSERT INTO ADDRESSES (id, country, city, street_name, zip_code) VALUES (2, 'England', 'London', 'Baker Street 46', ' NW1-6XE');
INSERT INTO ADDRESSES (id, country, city, street_name, zip_code) VALUES (3, 'Switzerland', 'Zurich', 'Bahnhofstrasse 34', '8001');
INSERT INTO ADDRESSES (id, country, city, street_name, zip_code) VALUES (4, 'Italy', 'Naples', 'Via Roma 25', '97484');

INSERT INTO ORDERS (id, total, customer_id, address_id) VALUES (1, 1225.00, 1, 1);
INSERT INTO ORDERS (id, total, customer_id, address_id) VALUES (2, 295.00, 2, 2);
INSERT INTO ORDERS (id, total, customer_id, address_id) VALUES (3, 1450.00, 3, 3);
INSERT INTO ORDERS (id, total, customer_id, address_id) VALUES (4, 1520.00, 4, 4);

INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (1, 1);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (1, 2);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (2, 3);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (2, 4);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (3, 1);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (3, 4);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (4, 1);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (4, 2);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (4, 3);
INSERT INTO ORDERS_PRODUCTS (order_id, product_id) VALUES (4, 4);


