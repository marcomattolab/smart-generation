package ch.elca.skelify.backend.security;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.util.CollectionUtils;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.*;
import java.util.stream.Collectors;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
@RequiredArgsConstructor
public class SecurityConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityConfig.class);

    @Value("${app.cors.allowed-origins}")
    private String allowedOriginsString;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(getOpenedResources()).permitAll()
                        .anyRequest().authenticated())
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(jwt -> jwt.jwtAuthenticationConverter(jwtAuthenticationConverter())))
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        return http.build();
    }

    private JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtGrantedAuthoritiesConverter defaultConverter = new JwtGrantedAuthoritiesConverter();
        defaultConverter.setAuthorityPrefix("ROLE_");
        defaultConverter.setAuthoritiesClaimName("scope");

        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setJwtGrantedAuthoritiesConverter(jwt -> {
            Set<GrantedAuthority> authorities = new LinkedHashSet<>();

            // 1. Standard scopes from default converter
            Collection<GrantedAuthority> defaultAuthorities = defaultConverter.convert(jwt);
            if (!CollectionUtils.isEmpty(defaultAuthorities)) {
                authorities.addAll(defaultAuthorities);
            }
            // 2. Realm roles with defensive null checks
            extractRealmRoles(jwt).ifPresent(authorities::addAll);

            // 3. Client roles with defensive processing
            extractClientRoles(jwt).ifPresent(authorities::addAll);

            return Set.copyOf(authorities); // Return immutable set
        });

        return converter;
    }

    private Optional<Set<GrantedAuthority>> extractRealmRoles(Jwt jwt) {
        try {
            Map<String, Object> realmAccess = jwt.getClaim("realm_access");
            if (realmAccess == null) {
                return Optional.empty();
            }
            Object rolesClaim = realmAccess.get("roles");
            if (!(rolesClaim instanceof Collection<?> roles)) {
                return Optional.empty();
            }
            Set<GrantedAuthority> realmRoles = roles.stream()
                    .filter(Objects::nonNull)
                    .map(Object::toString)
                    .filter(role -> !role.trim().isEmpty())
                    .map(role -> "ROLE_" + role.toUpperCase())
                    .distinct()
                    .map(SimpleGrantedAuthority::new)
                    .collect(Collectors.toCollection(LinkedHashSet::new));
            return Optional.of(realmRoles);
        } catch (Exception e) {
            LOGGER.debug("Failed to extract realm roles: {}", e.getMessage());
            return Optional.empty();
        }
    }

    private Optional<Set<GrantedAuthority>> extractClientRoles(Jwt jwt) {
        try {
            Map<String, Object> resourceAccess = jwt.getClaim("resource_access");
            if (resourceAccess == null) {
                return Optional.empty();
            }
            Set<GrantedAuthority> clientRoles = new LinkedHashSet<>();
            resourceAccess.forEach((client, accessData) -> {
                if (accessData instanceof Map<?, ?> clientAccess) {
                    Object rolesClaim = clientAccess.get("roles");
                    if (rolesClaim instanceof Collection<?> roles) {
                        roles.stream()
                                .filter(Objects::nonNull)
                                .map(Object::toString)
                                .filter(role -> !role.trim().isEmpty())
                                .map(role -> "ROLE_" + role.toUpperCase())
                                .distinct()
                                .map(SimpleGrantedAuthority::new)
                                .forEach(clientRoles::add);
                    }
                }
            });

            return Optional.of(clientRoles);
        } catch (Exception e) {
            LOGGER.debug("Failed to extract client roles: {}", e.getMessage());
            return Optional.empty();
        }
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        List<String> allowedOrigins = Arrays.asList(allowedOriginsString.split(","));

        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(allowedOrigins);
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        config.setExposedHeaders(List.of("Authorization", "Content-Disposition"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    // opened endpoints
    private String[] getOpenedResources() {
        return new String[]{
                "/actuator/health/**",
                "/swagger-ui/**",
                "/swagger-resources",
                "/swagger-resources/**",
                "/v3/api-docs",
                "/v3/api-docs/**",
                "/api/documents/specification"
        };
    }
}

