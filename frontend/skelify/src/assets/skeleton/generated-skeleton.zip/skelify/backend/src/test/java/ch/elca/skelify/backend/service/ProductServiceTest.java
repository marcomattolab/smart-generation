/*
package ch.elca.skelify.backend.service;

import ch.elca.skelify.backend.exception.EntityAlreadyExistException;
import ch.elca.skelify.backend.exception.EntityNotFoundException;
import ch.elca.skelify.backend.model.dto.ProductDto;
import ch.elca.skelify.backend.model.entity.ProductEntity;
import ch.elca.skelify.backend.repository.ProductRepository;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Optional;

import static ch.elca.skelify.backend.utility.ProductUtils.createProductDtos;
import static ch.elca.skelify.backend.utility.ProductUtils.createProductEntities;
import static org.junit.Assert.assertEquals;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

*/
/**
 *
 * @author savr
 *//*

@ActiveProfiles("test")
@RunWith(MockitoJUnitRunner.class)
@DisplayName("Test ProductService operations")
public class ProductServiceTest {

    @InjectMocks
    private ProductService productService;

    @Mock
    private ProductRepository productRepository;

    @Test
    public void testGetProducts() {
        // Given
        List<ProductEntity> productEntities = createProductEntities();
        List<ProductDto> expectedDtos = createProductDtos();

        when(productRepository.findAll()).thenReturn(productEntities);

        // When
        List<ProductDto> outputDtos = productService.getProducts();

        // Then
        assertThat(outputDtos)
                .hasSize(4)
                .usingRecursiveComparison()
                .isEqualTo(expectedDtos);
    }

    @Test
    public void testGetProductById() {
        // Given
        List<ProductEntity> productEntities = createProductEntities();
        List<ProductDto> expectedDtos = createProductDtos();

        when(productRepository.findById(1L)).thenReturn(Optional.ofNullable(productEntities.get(0)));
        when(productRepository.findById(2L)).thenReturn(Optional.ofNullable(productEntities.get(1)));
        when(productRepository.findById(3L)).thenReturn(Optional.ofNullable(productEntities.get(2)));
        when(productRepository.findById(4L)).thenReturn(Optional.ofNullable(productEntities.get(3)));

        // When
        ProductDto outputDto1 = productService.getProductById(1L);
        ProductDto outputDto2 = productService.getProductById(2L);
        ProductDto outputDto3 = productService.getProductById(3L);
        ProductDto outputDto4 = productService.getProductById(4L);

        // Then
        assertThat(outputDto1)
                .usingRecursiveComparison()
                .isEqualTo(expectedDtos.get(0));

        assertThat(outputDto2)
                .usingRecursiveComparison()
                .isEqualTo(expectedDtos.get(1));

        assertThat(outputDto3)
                .usingRecursiveComparison()
                .isEqualTo(expectedDtos.get(2));

        assertThat(outputDto4)
                .usingRecursiveComparison()
                .isEqualTo(expectedDtos.get(3));
    }


    @Test
    public void testGetProductByIdNotEntityNotFoundException() {
        // Given
        when(productRepository.findById(anyLong())).thenReturn(Optional.empty());

        // When & Then
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            productService.getProductById(1L);
        });

        assertEquals("Product not found", exception.getMessage());
    }

    @Test
    public void testCreateProduct() {
        // Given
        ProductEntity entity = createProductEntities().getFirst();
        ProductDto expectedOutput = createProductDtos().getFirst();
        when(productRepository.findById(anyLong())).thenReturn(Optional.empty());
        when(productRepository.save(any())).thenReturn(entity);

        // When
        ProductDto output = productService.createProduct(createProductDtos().getFirst());

        // Then
        assertThat(output)
                .usingRecursiveComparison()
                .isEqualTo(expectedOutput);
    }

    @Test
    public void testCreateProductEntityAlreadyExistException() {
        // Given
        ProductDto inputDto = createProductDtos().getFirst();
        ProductEntity existingEntity = createProductEntities().getFirst();
        when(productRepository.findById(anyLong())).thenReturn(Optional.of(existingEntity));

        // When & Then
        EntityAlreadyExistException exception = assertThrows(
                EntityAlreadyExistException.class,
                () -> productService.createProduct(inputDto));


        assertEquals("Product already exists", exception.getMessage());
    }

    @Test
    public void testUpdateProduct() {
        // Given
        ProductEntity originalEntity = createProductEntities().getFirst();
        ProductDto updatedProduct = ProductDto.builder().id(1L).name("Macbook Pro").price(2500D).build();
        ProductEntity updatedEntity = ProductEntity.builder().id(1L).name("Macbook Pro").price(2500D).build();
        when(productRepository.findById(anyLong())).thenReturn(Optional.of(originalEntity));
        when(productRepository.save(any())).thenReturn(updatedEntity);

        // When
        ProductDto output = productService.updateProduct(updatedProduct);

        // Then
        assertThat(output)
                .usingRecursiveComparison()
                .isEqualTo(updatedProduct);
    }

    @Test
    public void testUpdateProductEntityNotFoundException() {
        // Given
        ProductDto inputDto = createProductDtos().getFirst();
        when(productRepository.findById(anyLong())).thenReturn(Optional.empty());

        // When & Then
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            productService.updateProduct(inputDto);
        });

        assertEquals("Product not found", exception.getMessage());
    }


    @Test
    public void testDeleteProduct() {
        // Given
        when(productRepository.existsById(anyLong())).thenReturn(true);

        // When
        productService.deleteProduct(1L);

        // Then
        verify(productRepository, times(1)).deleteById(anyLong());
    }

    @Test
    public void testDeleteProductEntityNotFoundException() {
        // Given
        when(productRepository.existsById(anyLong())).thenReturn(false);

        // When
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            productService.deleteProduct(1L);
        });

        assertEquals("Product not found", exception.getMessage());

        // Then
        verify(productRepository, times(0)).deleteById(anyLong());
    }
}
*/
