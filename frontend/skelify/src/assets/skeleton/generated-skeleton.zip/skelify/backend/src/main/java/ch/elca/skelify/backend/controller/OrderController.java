package ch.elca.skelify.backend.controller;

import ch.elca.skelify.backend.model.dto.CreateOrderDto;
import ch.elca.skelify.backend.model.dto.OrderDto;
import ch.elca.skelify.backend.model.dto.UpdateOrderDto;
import ch.elca.skelify.backend.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/order")
public class OrderController {


    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }


    @GetMapping("")
    @Operation(
            summary = "Return all orders",
            description = "All orders endpoint that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<List<OrderDto>> getOrders() {
        return ResponseEntity.ok(orderService.getOrders());
    }


    @GetMapping("/{id}")
    @Operation(
            summary = "Return orders from ID",
            description = "Order endpoint from ID that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<OrderDto> getOrderById(@PathVariable(name = "id") Long id) {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }


    @PostMapping(path = "")
    @Operation(
            summary = "Create a new order",
            description = "Create a new order that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<OrderDto> createOrder(@RequestBody @Valid @NotNull CreateOrderDto orderDto) {
        return ResponseEntity.ok(orderService.createOrder(orderDto));
    }

    @PutMapping(path = "")
    @Operation(
            summary = "Update order products",
            description = "Update order products that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<OrderDto> updateOrder(@RequestBody @Valid @NotNull UpdateOrderDto orderDto) {
        return ResponseEntity.ok(orderService.updateOrderProducts(orderDto));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Delete an order",
            description = "Delete an order that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity deleteOrder(@PathVariable(name = "id") Long id) {
        orderService.deleteOrder(id);
        return ResponseEntity.ok().build();
    }
}
