package ch.elca.skelify.backend.model.dto;

import lombok.Builder;

/**
 *
 * @author savr
 */
@Builder
public record AddressDto(Long id,
                         String country,
                         String city,
                         String streetName,
                         String zipCode) {
}
