package ch.elca.skelify.backend.exception;

import lombok.Getter;
@Getter
public class EntityNotFoundException extends RuntimeException {
    private final String entityType;
    private final Long id;

    public EntityNotFoundException(String entityType, Long id) {
        super(String.format("%s not found", entityType));
        this.entityType = entityType;
        this.id = id;
    }
}
