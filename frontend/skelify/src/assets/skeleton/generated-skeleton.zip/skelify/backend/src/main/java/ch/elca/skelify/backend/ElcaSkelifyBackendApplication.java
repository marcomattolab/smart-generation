package ch.elca.skelify.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElcaSkelifyBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElcaSkelifyBackendApplication.class, args);
	}

}
