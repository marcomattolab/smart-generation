package ch.elca.skelify.backend.exception;

import lombok.Getter;

@Getter
public class SkelifyBusinessException extends RuntimeException {
  private final String errorCode;

  public SkelifyBusinessException(String message) {
    super(message);
    this.errorCode = "BUSINESS_ERROR";
  }

  public SkelifyBusinessException(String errorCode, String message) {
    super(message);
    this.errorCode = errorCode;
  }

}
