/*
package ch.elca.skelify.backend.controller;

import ch.elca.skelify.backend.model.dto.ProductDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureDataJpa;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static ch.elca.skelify.backend.utility.ProductUtils.createProductDtos;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

*/
/**
 *
 * @author savr
 *//*

@Transactional
@Sql(scripts = "classpath:sql/data.sql", executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@AutoConfigureDataJpa
class ProductControllerIntegrationTest {

    private static final String BASE_PATH = "/api/v1/product";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private String jwtToken = "";


    @BeforeEach
    void setup() throws JsonProcessingException {
        RestTemplate restTemplate = new RestTemplate();

        String keycloakEndPoint = "http://keycloak-prj-elca-skelify.apps.okd.svc.elca.ch/realms/skelify/protocol/openid-connect/token";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("client_id", "skelify");
        formData.add("client_secret", "aObRJB9KpoQPncuY7GESaZ74zq7lURJF");
        formData.add("username", "user1");
        formData.add("password", "user1");
        formData.add("grant_type", "password");

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);

        ResponseEntity<String> response = restTemplate.exchange(
                keycloakEndPoint,
                HttpMethod.POST,
                request,
                String.class
        );

        JsonNode json = objectMapper.readTree(response.getBody());
        jwtToken = json.get("access_token").asText();
    }

    @Test
    void testGetAllProduct() throws Exception {

        List<ProductDto> productDtos = createProductDtos();

        ResultActions result = mockMvc.perform(
                        get(BASE_PATH)
                                .contentType(MediaType.APPLICATION_JSON)
                                .header("Authorization", "Bearer " + jwtToken)
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isNotEmpty())
                .andExpect(jsonPath("$.length()").value(4))
                .andDo(print());

        for (int i = 0; i < productDtos.size(); i++) {
            ProductDto dto = productDtos.get(i);
            result.andExpect(jsonPath("$[" + i + "].id").value(dto.id()))
                    .andExpect(jsonPath("$[" + i + "].name").value(dto.name()))
                    .andExpect(jsonPath("$[" + i + "].price").value(dto.price()));
        }
    }


    @Test
    void testGetProductById() throws Exception {
        mockMvc.perform(
                get(String.join("/", BASE_PATH, "1"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + jwtToken)
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("1"))
                .andExpect(jsonPath("$.name").value("Laptop"))
                .andExpect(jsonPath("$.price").value(1200))
                .andDo(print());
    }

    @Test
    void testGetProductByIdEntityNotFoundException() throws Exception {
        mockMvc.perform(
                        get(String.join("/", BASE_PATH, "999"))
                                .contentType(MediaType.APPLICATION_JSON)
                                .header("Authorization", "Bearer " + jwtToken)
                )
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errorCode").value("RESOURCE_NOT_FOUND"))
                .andExpect(jsonPath("$.message").value("Resource not found"))
                .andExpect(jsonPath("$.details").value("Entity of type 'Product' with ID: '999' does not exist"))
                .andExpect(jsonPath("$.method").value("GET"))
                .andExpect(jsonPath("$.path").value("/api/v1/product/999"))
                .andExpect(jsonPath("$.metadata.entityType").value("Product"))
                .andExpect(jsonPath("$.metadata.id").value(999))
                .andExpect(jsonPath("$.timestamp").isNotEmpty())
                .andDo(print());
    }

    @Test
    void testCreateProduct() throws Exception {
        ProductDto newProduct = new ProductDto( 5L, "Webcam", 15.0);

        String jsonBody = objectMapper.writeValueAsString(newProduct);

        mockMvc.perform(
                        post(BASE_PATH)
                                .contentType(MediaType.APPLICATION_JSON)
                                .header("Authorization", "Bearer " + jwtToken)
                                .content(jsonBody)
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.id").value(5))
                .andExpect(jsonPath("$.name").value("Webcam"))
                .andExpect(jsonPath("$.price").value(15.0))
                .andDo(print());
    }

    @Test
    void testCreateProductEntityAlreadyExistException() throws Exception {
        ProductDto newProduct = new ProductDto( 4L, "Webcam", 15.0);

        String jsonBody = objectMapper.writeValueAsString(newProduct);

        mockMvc.perform(
                        post(BASE_PATH)
                                .contentType(MediaType.APPLICATION_JSON)
                                .header("Authorization", "Bearer " + jwtToken)
                                .content(jsonBody)
                )
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.errorCode").value("CONFLICT"))
                .andExpect(jsonPath("$.message").value("Resource conflict"))
                .andExpect(jsonPath("$.details").value("Entity of type 'Product' with ID: '4' already exists"))
                .andExpect(jsonPath("$.method").value("POST"))
                .andExpect(jsonPath("$.path").value("/api/v1/product"))
                .andExpect(jsonPath("$.metadata.entityType").value("Product"))
                .andExpect(jsonPath("$.metadata.id").value(4))
                .andExpect(jsonPath("$.timestamp").isNotEmpty())
                .andDo(print());
    }

    @Test
    void testUpdateProduct() throws Exception {
        ProductDto newProduct = new ProductDto( 4L, "Webcam", 5.0);

        String jsonBody = objectMapper.writeValueAsString(newProduct);

        mockMvc.perform(
                        put(BASE_PATH)
                                .contentType(MediaType.APPLICATION_JSON)
                                .header("Authorization", "Bearer " + jwtToken)
                                .content(jsonBody)
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.id").value(4))
                .andExpect(jsonPath("$.name").value("Webcam"))
                .andExpect(jsonPath("$.price").value(5.0))
                .andDo(print());
    }

    @Test
    void testUpdateProductEntityNotFoundException() throws Exception {
        ProductDto newProduct = new ProductDto( 5L, "Webcam", 5.0);

        String jsonBody = objectMapper.writeValueAsString(newProduct);

        mockMvc.perform(
                        put(BASE_PATH)
                                .contentType(MediaType.APPLICATION_JSON)
                                .header("Authorization", "Bearer " + jwtToken)
                                .content(jsonBody)
                )
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errorCode").value("RESOURCE_NOT_FOUND"))
                .andExpect(jsonPath("$.message").value("Resource not found"))
                .andExpect(jsonPath("$.details").value("Entity of type 'Product' with ID: '5' does not exist"))
                .andExpect(jsonPath("$.path").value("/api/v1/product"))
                .andExpect(jsonPath("$.metadata.entityType").value("Product"))
                .andExpect(jsonPath("$.method").value("PUT"))
                .andExpect(jsonPath("$.metadata.id").value(5))
                .andExpect(jsonPath("$.timestamp").isNotEmpty())
                .andDo(print());
    }

    @Test
    void testDeleteProductEntity() throws Exception {
        mockMvc.perform(
                        delete(String.join("/", BASE_PATH, "4"))
                                .contentType(MediaType.APPLICATION_JSON)
                                .header("Authorization", "Bearer " + jwtToken)
                )
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    void testDeleteProductEntityNotFoundException() throws Exception {
        mockMvc.perform(
                        delete(String.join("/", BASE_PATH, "999"))
                                .contentType(MediaType.APPLICATION_JSON)
                                .header("Authorization", "Bearer " + jwtToken)
                )
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errorCode").value("RESOURCE_NOT_FOUND"))
                .andExpect(jsonPath("$.message").value("Resource not found"))
                .andExpect(jsonPath("$.details").value("Entity of type 'Product' with ID: '999' does not exist"))
                .andExpect(jsonPath("$.method").value("DELETE"))
                .andExpect(jsonPath("$.path").value("/api/v1/product/999"))
                .andExpect(jsonPath("$.metadata.entityType").value("Product"))
                .andExpect(jsonPath("$.metadata.id").value(999))
                .andExpect(jsonPath("$.timestamp").isNotEmpty())
                .andDo(print());
    }

}


*/
