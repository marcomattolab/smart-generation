package ch.elca.skelify.backend.security;

import ch.elca.skelify.backend.security.dto.AuthenticatedUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.util.Optional;

public final class SecurityUtils {

    public static AuthenticatedUser getCurrentUser() {
        return getOptionalUser().orElseThrow(() -> new SecurityException("No Authentication found"));
    }

    public static String getCurrentUserName() {
        return getCurrentUser().getUsername();
    }

    private static Optional<AuthenticatedUser> getOptionalUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new SecurityException("No Authentication found");
        }

        Object principal = authentication.getPrincipal();

        if (principal instanceof OidcUser oidcUser) {
            return Optional.of(createUserFromOidc(oidcUser));
        } else if (principal instanceof Jwt jwt) {
            return Optional.of(createUserFromJwt(jwt));
        } else if (principal instanceof JwtAuthenticationToken jwtAuth) {
            return Optional.of(createUserFromJwt(jwtAuth.getToken()));
        }

        throw new SecurityException("Unsupported authentication type: " + principal.getClass().getName());
    }

    private static AuthenticatedUser createUserFromOidc(OidcUser oidcUser) {
        AuthenticatedUser user = new AuthenticatedUser();
        user.setUsername(oidcUser.getPreferredUsername());
        user.setEmail(oidcUser.getEmail());
        user.setFirstName(oidcUser.getGivenName());
        user.setLastName(oidcUser.getFamilyName());
        return user;
    }

    private static AuthenticatedUser createUserFromJwt(Jwt jwt) {
        AuthenticatedUser user = new AuthenticatedUser();
        user.setUsername(jwt.getClaimAsString("preferred_username"));
        user.setEmail(jwt.getClaimAsString("email"));
        user.setFirstName(jwt.getClaimAsString("given_name"));
        user.setLastName(jwt.getClaimAsString("family_name"));
        return user;
    }

    // Extract JWT
    public static Optional<String> getJwtToken() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication instanceof JwtAuthenticationToken jwtAuth) {
            return Optional.of(jwtAuth.getToken().getTokenValue());
        }
        return Optional.empty();
    }

    // Get claims of JWT
    public static <T> Optional<T> getJwtClaim(String claimName, Class<T> claimType) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication instanceof JwtAuthenticationToken jwtAuth) {
            return Optional.ofNullable(jwtAuth.getToken().getClaim(claimName));
        } else if (authentication.getPrincipal() instanceof Jwt jwt) {
            return Optional.ofNullable(jwt.getClaim(claimName));
        }
        return Optional.empty();
    }

    // check roles
    public static boolean hasRole(String role) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals("ROLE_" + role));
    }

    private SecurityUtils() {
        // Utility class
    }
}
