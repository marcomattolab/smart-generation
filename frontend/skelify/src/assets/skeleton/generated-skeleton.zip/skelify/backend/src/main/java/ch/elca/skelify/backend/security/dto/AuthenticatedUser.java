package ch.elca.skelify.backend.security.dto;

import lombok.Data;

@Data
public class AuthenticatedUser {
    private String username;
    private String email;
    private String firstName;
    private String lastName;
}
