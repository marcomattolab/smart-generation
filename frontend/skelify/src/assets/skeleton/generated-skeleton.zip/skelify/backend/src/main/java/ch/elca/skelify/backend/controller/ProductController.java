package ch.elca.skelify.backend.controller;

import ch.elca.skelify.backend.model.dto.ProductDto;
import ch.elca.skelify.backend.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/product")
public class ProductController {


    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }


    @GetMapping("")
    @Operation(
            summary = "Return all products",
            description = "All products endpoint that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<List<ProductDto>> getProducts() {
        return ResponseEntity.ok(productService.getProducts());
    }


    @GetMapping("/{id}")
    @Operation(
            summary = "Return product from ID",
            description = "Prdouct endpoint from ID that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<ProductDto> getProductById(@PathVariable(name = "id") Long id) {
        return ResponseEntity.ok(productService.getProductById(id));
    }

    @PostMapping(path = "")
    @Operation(
            summary = "Create a new product",
            description = "Create a new product that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<ProductDto> createProduct(@RequestBody @Valid @NotNull ProductDto productDto) {
        return ResponseEntity.ok(productService.createProduct(productDto));
    }

    @PutMapping(path = "")
    @Operation(
            summary = "Update a product",
            description = "Update a product that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<ProductDto> updateProduct(@RequestBody @Valid @NotNull ProductDto productDto) {
        return ResponseEntity.ok(productService.updateProduct(productDto));
    }


    @DeleteMapping("/{id}")
    @Operation(
            summary = "Delete a product",
            description = "Delete a product that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity deleteProduct(@PathVariable(name = "id") Long id) {
        productService.deleteProduct(id);
        return ResponseEntity.ok().build();
    }
}
