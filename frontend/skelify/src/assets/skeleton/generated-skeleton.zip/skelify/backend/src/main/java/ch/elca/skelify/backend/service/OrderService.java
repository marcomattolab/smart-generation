package ch.elca.skelify.backend.service;

import ch.elca.skelify.backend.exception.EntityAlreadyExistException;
import ch.elca.skelify.backend.exception.EntityNotFoundException;
import ch.elca.skelify.backend.mapper.EntityMappers;
import ch.elca.skelify.backend.model.dto.CreateOrderDto;
import ch.elca.skelify.backend.model.dto.OrderDto;
import ch.elca.skelify.backend.model.dto.UpdateOrderDto;
import ch.elca.skelify.backend.model.entity.AddressEntity;
import ch.elca.skelify.backend.model.entity.CustomerEntity;
import ch.elca.skelify.backend.model.entity.OrderEntity;
import ch.elca.skelify.backend.model.entity.ProductEntity;
import ch.elca.skelify.backend.repository.AddressRepository;
import ch.elca.skelify.backend.repository.CustomerRepository;
import ch.elca.skelify.backend.repository.OrderRepository;
import ch.elca.skelify.backend.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 *
 * @author savr
 */
@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;
    private final AddressRepository addressRepository;


    public OrderService(OrderRepository orderRepository,  CustomerRepository customerRepository, ProductRepository productRepository, AddressRepository addressRepository) {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
        this.addressRepository = addressRepository;

    }

    public List<OrderDto> getOrders() {
        return EntityMappers.CollectionMapper.orderEntitiesToOrderDtos(orderRepository.findAll());
    }

    public OrderDto getOrderById(Long id) {
        return orderRepository.findById(id)
                .map(EntityMappers.OrderMapper::orderEntityToOrderDto)
                .orElseThrow(() -> new EntityNotFoundException("Order", id));
    }

    public OrderDto createOrder(CreateOrderDto createOrderDto) {

        orderRepository.findById(createOrderDto.orderId()).ifPresent(productEntity -> {
            throw new EntityAlreadyExistException("Order", createOrderDto.orderId());
        });

        CustomerEntity customer = customerRepository.findById(createOrderDto.customerId())
                .orElseThrow(() -> new EntityNotFoundException("Customer", createOrderDto.customerId()));

        AddressEntity address = addressRepository.findById(createOrderDto.addressId())
                .orElseThrow(() -> new EntityNotFoundException("Address", createOrderDto.addressId()));


        List<ProductEntity> products = checkProducts(createOrderDto.productIds());


        Double total = products.stream()
                .mapToDouble(ProductEntity::getPrice)
                .sum();

        OrderEntity savedOrder = orderRepository.save(
                OrderEntity.builder()
                        .id(createOrderDto.orderId())
                        .address(address)
                        .customer(customer)
                        .products(products)
                        .total(total).build());

        return EntityMappers.OrderMapper.orderEntityToOrderDto(savedOrder);
    }

    public OrderDto updateOrderProducts(UpdateOrderDto  updateOrderDto) {

        OrderEntity order = orderRepository.findById(updateOrderDto.orderId())
                .orElseThrow(() -> new EntityNotFoundException("Order", updateOrderDto.orderId()));

        List<ProductEntity> products = checkProducts(updateOrderDto.productIds());

        order.setProducts(products);

        Double total = products.stream()
                .mapToDouble(ProductEntity::getPrice)
                .sum();
        order.setTotal(total);

        return EntityMappers.OrderMapper.orderEntityToOrderDto(orderRepository.save(order));
    }

    public void deleteOrder(Long id) {
        if (orderRepository.existsById(id)) {
            orderRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("Order", id);
        }
    }

    private List<ProductEntity> checkProducts(List<Long> productIds) {
        List<ProductEntity> products = productRepository.findAllById(productIds);

        Set<Long> foundProductIds = products.stream()
                .map(ProductEntity::getId)
                .collect(Collectors.toSet());

        List<Long> missingProductIds = productIds.stream()
                .filter(id -> !foundProductIds.contains(id))
                .toList();

        if (!missingProductIds.isEmpty()) {
            throw new EntityNotFoundException("Product", missingProductIds.getFirst());
        }

        return products;
    }

}
