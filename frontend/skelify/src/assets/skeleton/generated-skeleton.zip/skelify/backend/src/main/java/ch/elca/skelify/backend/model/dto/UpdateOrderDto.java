package ch.elca.skelify.backend.model.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;

import java.util.List;

/**
 *
 * @author savr
 */
@Builder
public record UpdateOrderDto(@NotNull Long orderId,
                             @NotEmpty List<Long> productIds) {
}
