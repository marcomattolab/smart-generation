package ch.elca.skelify.backend.exception;

import lombok.Getter;

@Getter
public class EntityAlreadyExistException extends RuntimeException {
    private final String entityType;
    private final Long id;

    public EntityAlreadyExistException(String entityType, Long id) {
        super(String.format("%s already exists", entityType));
        this.entityType = entityType;
        this.id = id;
    }

}
