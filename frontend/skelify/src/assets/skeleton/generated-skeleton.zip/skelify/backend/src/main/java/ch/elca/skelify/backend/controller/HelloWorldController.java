package ch.elca.skelify.backend.controller;

import ch.elca.skelify.backend.security.dto.AuthenticatedUser;
import ch.elca.skelify.backend.security.SecurityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/hello")
public class HelloWorldController {

    @GetMapping("")
    @PreAuthorize("hasRole('USER')")
    @Operation(
            summary = "Protected Hello",
            description = "Hello endpoint that requires JWT authentication"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<AuthenticatedUser> hello() {
        return ResponseEntity.ok(SecurityUtils.getCurrentUser());
    }

}
