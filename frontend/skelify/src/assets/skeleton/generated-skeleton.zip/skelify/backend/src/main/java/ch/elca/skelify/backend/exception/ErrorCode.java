package ch.elca.skelify.backend.exception;

import lombok.Getter;

@Getter
public enum ErrorCode {

    // Validation errors (4xx)
    VALIDATION_ERROR("VALIDATION_ERROR",
            "Validation errors in provided data",
            "One or more fields contain invalid values"),

    INVALID_REQUEST("INVALID_REQUEST",
            "Invalid request format",
            "The request body or parameters are malformed"),

    MISSING_PARAMETER("MISSING_PARAMETER",
            "Required parameter missing",
            "A mandatory request parameter is not provided"),

    TYPE_MISMATCH("TYPE_MISMATCH",
            "Parameter type mismatch",
            "Parameter value cannot be converted to expected type"),

    MALFORMED_JSON("MALFORMED_JSON",
            "Malformed JSON request",
            "The request body contains invalid JSON"),

    // Resource errors (4xx)
    RESOURCE_NOT_FOUND("RESOURCE_NOT_FOUND",
            "Resource not found",
            "The requested resource does not exist"),

    ENDPOINT_NOT_FOUND("ENDPOINT_NOT_FOUND",
            "Endpoint not found",
            "The requested endpoint does not exist"),

    // Security errors (4xx)
    UNAUTHORIZED("UNAUTHORIZED",
            "Authentication required",
            "Valid credentials are required to access this resource"),

    FORBIDDEN("FORBIDDEN",
            "Access denied",
            "You don't have permission to access this resource"),

    BAD_CREDENTIALS("BAD_CREDENTIALS",
            "Invalid credentials",
            "The provided credentials are incorrect"),

    // Method/Media errors (4xx)
    METHOD_NOT_ALLOWED("METHOD_NOT_ALLOWED",
            "HTTP method not supported",
            "The HTTP method used is not supported for this endpoint"),

    UNSUPPORTED_MEDIA_TYPE("UNSUPPORTED_MEDIA_TYPE",
            "Unsupported content type",
            "The provided content type is not supported"),

    // Business logic errors (4xx)
    BUSINESS_RULE_VIOLATION("BUSINESS_RULE_VIOLATION",
            "Business rule violation",
            "The operation violates business rules"),

    CONFLICT("CONFLICT",
            "Resource conflict",
            "The operation conflicts with the current state of the resource"),

    DATA_INTEGRITY_VIOLATION("DATA_INTEGRITY_VIOLATION",
            "Data integrity constraint violation",
            "The operation would violate database integrity constraints"),

    // Server errors (5xx)
    INTERNAL_SERVER_ERROR("INTERNAL_SERVER_ERROR",
            "Internal server error",
            "An unexpected error occurred while processing the request"),

    DATABASE_ERROR("DATABASE_ERROR",
            "Database access error",
            "An error occurred while accessing the database"),

    EXTERNAL_SERVICE_ERROR("EXTERNAL_SERVICE_ERROR",
            "External service error",
            "An error occurred while communicating with an external service"),

    SERVICE_UNAVAILABLE("SERVICE_UNAVAILABLE",
            "Service unavailable",
            "The service is temporarily unavailable"),

    TIMEOUT_ERROR("TIMEOUT_ERROR",
            "Operation timeout",
            "The operation timed out while processing"),

    // business error codes
    DUPLICATE_DOCUMENT("DUPLICATE_DOCUMENT",
            "Duplicate document",
            "Duplicate document");

    private final String code;
    private final String message;
    private final String details;

    ErrorCode(String code, String message, String details) {
        this.code = code;
        this.message = message;
        this.details = details;
    }

}
