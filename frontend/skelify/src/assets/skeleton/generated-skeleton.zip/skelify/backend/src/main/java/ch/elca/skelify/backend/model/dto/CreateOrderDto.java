package ch.elca.skelify.backend.model.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;

import java.util.List;

/**
 *
 * @author savr
 */
@Builder
public record CreateOrderDto(@NotNull Long orderId,
                             @NotNull Long addressId,
                             @NotNull Long customerId,
                             @NotEmpty List<Long> productIds) {
}
