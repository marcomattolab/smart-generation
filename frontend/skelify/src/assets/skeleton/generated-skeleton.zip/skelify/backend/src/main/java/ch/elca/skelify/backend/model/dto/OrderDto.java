package ch.elca.skelify.backend.model.dto;

import lombok.Builder;

import java.util.List;

/**
 *
 * @author savr
 */
@Builder
public record OrderDto(Long id,
                       Double total,
                       AddressDto address,
                       CustomerDto customer,
                       List<ProductDto> products) {
}
