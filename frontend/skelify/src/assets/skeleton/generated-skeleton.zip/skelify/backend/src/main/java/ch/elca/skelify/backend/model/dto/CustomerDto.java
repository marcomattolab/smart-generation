package ch.elca.skelify.backend.model.dto;
import lombok.Builder;

import java.util.List;

/**
 *
 * @author savr
 */
@Builder
public record CustomerDto(Long id,
                          String name,
                          String surname,
                          String email,
                          List<OrderDto> orders) {
}
