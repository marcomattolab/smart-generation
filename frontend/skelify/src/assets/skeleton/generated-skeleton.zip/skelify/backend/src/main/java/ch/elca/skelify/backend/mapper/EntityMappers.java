package ch.elca.skelify.backend.mapper;

import ch.elca.skelify.backend.model.dto.AddressDto;
import ch.elca.skelify.backend.model.dto.CustomerDto;
import ch.elca.skelify.backend.model.dto.OrderDto;
import ch.elca.skelify.backend.model.dto.ProductDto;
import ch.elca.skelify.backend.model.entity.AddressEntity;
import ch.elca.skelify.backend.model.entity.CustomerEntity;
import ch.elca.skelify.backend.model.entity.OrderEntity;
import ch.elca.skelify.backend.model.entity.ProductEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author savr
 */
@Component
public class EntityMappers {

    // Customer Mapper
    public static class CustomerMapper {

        public static CustomerDto customerEntityToCustomerDto(CustomerEntity customerEntity) {
            if (customerEntity == null) {
                return null;
            }

            return CustomerDto.builder()
                    .id(customerEntity.getId())
                    .name(customerEntity.getName())
                    .surname(customerEntity.getSurname())
                    .email(customerEntity.getEmail())
                    .orders(customerEntity.getOrders() != null
                            ? CollectionMapper.orderEntitiesToOrderDtos(customerEntity.getOrders()).stream().toList()
                            : null)
                    .build();
        }

        public static CustomerDto customerEntityToCustomerDtoWithoutOrders(CustomerEntity customerEntity) {
            if (customerEntity == null) {
                return null;
            }

            return CustomerDto.builder()
                    .id(customerEntity.getId())
                    .name(customerEntity.getName())
                    .surname(customerEntity.getSurname())
                    .email(customerEntity.getEmail())
                    .orders(null) // <-- qui tagliamo il ciclo
                    .build();
        }

        public static CustomerEntity customerDtoToCustomerEntity(CustomerDto customerDto) {
            if (customerDto == null) {
                return null;
            }

            return CustomerEntity.builder()
                    .id(customerDto.id())
                    .name(customerDto.name())
                    .surname(customerDto.surname())
                    .email(customerDto.email())
                    .build();
        }
    }

    // Address Mapper
    public static class AddressMapper {

        public static AddressDto addressEntityToAddressDto(AddressEntity addressEntity) {
            if (addressEntity == null) {
                return null;
            }

            return AddressDto.builder()
                    .id(addressEntity.getId())
                    .country(addressEntity.getCountry())
                    .city(addressEntity.getCity())
                    .streetName(addressEntity.getStreetName())
                    .zipCode(addressEntity.getZipCode())
                    .build();
        }

        public static AddressEntity addressDtoToAddressEntity(AddressDto addressDto) {
            if (addressDto == null) {
                return null;
            }

            return AddressEntity.builder()
                    .id(addressDto.id())
                    .country(addressDto.country())
                    .city(addressDto.city())
                    .streetName(addressDto.streetName())
                    .zipCode(addressDto.zipCode())
                    .build();
        }
    }

    // Product Mapper
    public static class ProductMapper {

        public static ProductDto productEntityToProductDto(ProductEntity productEntity) {
            if (productEntity == null) {
                return null;
            }

            return ProductDto.builder()
                    .id(productEntity.getId())
                    .name(productEntity.getName())
                    .price(productEntity.getPrice())
                    .build();
        }

        public static ProductEntity productDtoToProductEntity(ProductDto productDto) {
            if (productDto == null) {
                return null;
            }

            return ProductEntity.builder()
                    .id(productDto.id())
                    .name(productDto.name())
                    .price(productDto.price())
                    .build();
        }
    }

    // Order Mapper
    public static class OrderMapper {

        public static OrderDto orderEntityToOrderDto(OrderEntity orderEntity) {
            if (orderEntity == null) {
                return null;
            }

            return OrderDto.builder()
                    .id(orderEntity.getId())
                    .total(orderEntity.getTotal())
                    .customer(orderEntity.getCustomer() != null
                            ? CustomerMapper.customerEntityToCustomerDtoWithoutOrders(orderEntity.getCustomer())
                            : null)
                    .address(orderEntity.getAddress() != null
                            ? AddressMapper.addressEntityToAddressDto(orderEntity.getAddress())
                            : null)
                    .products(orderEntity.getProducts() != null
                            ? CollectionMapper.productEntitiesToProductDtos(orderEntity.getProducts()).stream().toList()
                            : null)
                    .build();
        }

        public static OrderEntity orderDtoToOrderEntity(OrderDto orderDto) {
            if (orderDto == null) {
                return null;
            }

            return OrderEntity.builder()
                    .id(orderDto.id())
                    .total(orderDto.total())
                    .build();
        }
    }

    public static class CollectionMapper {

        public static List<CustomerDto> customerEntitiesToCustomerDtos(List<CustomerEntity> entities) {
            if (entities == null) {
                return null;
            }
            return entities.stream()
                    .map(CustomerMapper::customerEntityToCustomerDto)
                    .collect(Collectors.toList());
        }

        public static List<AddressDto> addressEntitiesToAddressDtos(List<AddressEntity> entities) {
            if (entities == null) {
                return null;
            }
            return entities.stream()
                    .map(AddressMapper::addressEntityToAddressDto)
                    .collect(Collectors.toList());
        }

        public static List<ProductDto> productEntitiesToProductDtos(List<ProductEntity> entities) {
            if (entities == null) {
                return null;
            }
            return entities.stream()
                    .map(ProductMapper::productEntityToProductDto)
                    .collect(Collectors.toList());
        }

        public static List<OrderDto> orderEntitiesToOrderDtos(List<OrderEntity> entities) {
            if (entities == null) {
                return null;
            }
            return entities.stream()
                    .map(OrderMapper::orderEntityToOrderDto)
                    .collect(Collectors.toList());
        }
    }
}
