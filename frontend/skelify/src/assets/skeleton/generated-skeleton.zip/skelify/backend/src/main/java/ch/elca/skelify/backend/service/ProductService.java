package ch.elca.skelify.backend.service;

import ch.elca.skelify.backend.exception.EntityAlreadyExistException;
import ch.elca.skelify.backend.exception.EntityNotFoundException;
import ch.elca.skelify.backend.mapper.EntityMappers;
import ch.elca.skelify.backend.model.dto.ProductDto;
import ch.elca.skelify.backend.model.entity.ProductEntity;
import ch.elca.skelify.backend.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 * @author savr
 */
@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<ProductDto> getProducts() {
        return EntityMappers.CollectionMapper.productEntitiesToProductDtos(productRepository.findAll());
    }

    public ProductDto getProductById(Long id) {
        return productRepository.findById(id)
                .map(EntityMappers.ProductMapper::productEntityToProductDto)
                .orElseThrow(() -> new EntityNotFoundException("Product", id));
    }

    public ProductDto createProduct(ProductDto productDto) {
        productRepository.findById(productDto.id()).ifPresent(productEntity -> {
            throw new EntityAlreadyExistException("Product", productDto.id());
        });

        return EntityMappers.ProductMapper.productEntityToProductDto(productRepository.save(EntityMappers.ProductMapper.productDtoToProductEntity(productDto)));
    }

    public ProductDto updateProduct(ProductDto productDto) {
        ProductEntity productEntity = productRepository.findById(productDto.id()).orElseThrow(() -> new EntityNotFoundException("Product", productDto.id()));
        productEntity.setName(productDto.name());
        productEntity.setPrice(productDto.price());
        return EntityMappers.ProductMapper.productEntityToProductDto(productRepository.save(productEntity));
    }


    public void deleteProduct(Long id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("Product", id);
        }
    }

}
