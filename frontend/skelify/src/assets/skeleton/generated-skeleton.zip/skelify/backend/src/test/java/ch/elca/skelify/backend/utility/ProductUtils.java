package ch.elca.skelify.backend.utility;

import ch.elca.skelify.backend.model.dto.ProductDto;
import ch.elca.skelify.backend.model.entity.ProductEntity;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author savr
 */
public class ProductUtils {

    public static List<ProductEntity> createProductEntities() {
        return Arrays.asList(
                ProductEntity.builder().id(1L).name("Laptop").price(1200.0D).build(),
                ProductEntity.builder().id(2L).name("Mouse").price(25.0D).build(),
                ProductEntity.builder().id(3L).name("Keyboard").price(45.0D).build(),
                ProductEntity.builder().id(4L).name("Monitor").price(250.0D).build()
        );
    }

    public static List<ProductDto> createProductDtos() {
        return Arrays.asList(
                ProductDto.builder().id(1L).name("Laptop").price(1200.0D).build(),
                ProductDto.builder().id(2L).name("Mouse").price(25.0D).build(),
                ProductDto.builder().id(3L).name("Keyboard").price(45.0D).build(),
                ProductDto.builder().id(4L).name("Monitor").price(250.0D).build()
        );
    }
}