package ch.elca.skelify.backend.repository;

import ch.elca.skelify.backend.model.entity.CustomerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author savr
 */
@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, Long> {
}
