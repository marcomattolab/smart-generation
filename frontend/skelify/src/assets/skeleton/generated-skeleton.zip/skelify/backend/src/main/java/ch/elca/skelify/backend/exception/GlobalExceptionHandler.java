package ch.elca.skelify.backend.exception;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Path;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    // ========== Custom Application Exceptions ==========

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiErrorResponse> handleResourceNotFound(ResourceNotFoundException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Resource not found [{}]: {}", traceId, ex.getMessage());

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("resourceType", ex.getResourceType());
        metadata.put("resourceId", ex.getResourceId());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.RESOURCE_NOT_FOUND,
                request,
                traceId
        );

        apiErrorResponse.setDetails(String.format("Resource of type '%s' with ID '%s' does not exist", ex.getResourceType(), ex.getResourceId()));
        apiErrorResponse.setMetadata(metadata);

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiErrorResponse);
    }

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<ApiErrorResponse> handleEntityNotFoundException(EntityNotFoundException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Entity not found [{}]: {}", traceId, ex.getMessage());

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("entityType", ex.getEntityType());
        metadata.put("id", ex.getId());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.RESOURCE_NOT_FOUND,
                request,
                traceId
        );

        apiErrorResponse.setDetails(String.format("Entity of type '%s' with ID: '%s' does not exist", ex.getEntityType(), ex.getId()));
        apiErrorResponse.setMetadata(metadata);

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiErrorResponse);
    }

    @ExceptionHandler(EntityAlreadyExistException.class)
    public ResponseEntity<ApiErrorResponse> handleEntityAlreadyExistException(EntityAlreadyExistException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Entity already exists [{}]: {}", traceId, ex.getMessage());

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("entityType", ex.getEntityType());
        metadata.put("id", ex.getId());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.CONFLICT,
                request,
                traceId
        );

        apiErrorResponse.setDetails(String.format("Entity of type '%s' with ID: '%s' already exists", ex.getEntityType(), ex.getId()));
        apiErrorResponse.setMetadata(metadata);

        return ResponseEntity.status(HttpStatus.CONFLICT).body(apiErrorResponse);
    }


    @ExceptionHandler(SkelifyBusinessException.class)
    public ResponseEntity<ApiErrorResponse> handleSkelifyBusinessException(SkelifyBusinessException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Business exception [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.BUSINESS_RULE_VIOLATION,
                request,
                traceId
        );

        apiErrorResponse.setDetails(ex.getMessage());

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("businessErrorCode", ex.getErrorCode());
        apiErrorResponse.setMetadata(metadata);

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(apiErrorResponse);
    }

    // ========== Validation Exceptions ==========

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiErrorResponse> handleConstraintViolation(ConstraintViolationException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Constraint violation [{}]: {}", traceId, ex.getMessage());

        List<ApiErrorResponse.ValidationError> validationErrors = ex.getConstraintViolations()
                .stream()
                .map(violation -> ApiErrorResponse.ValidationError.builder()
                        .field(getFieldName(violation))
                        .rejectedValue(violation.getInvalidValue())
                        .message(violation.getMessage())
                        .build())
                .toList();

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.VALIDATION_ERROR,
                request,
                traceId
        );
        apiErrorResponse.setValidationErrors(validationErrors);

        return ResponseEntity.badRequest().body(apiErrorResponse);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiErrorResponse> handleValidationException(MethodArgumentNotValidException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Validation error [{}]: {}", traceId, ex.getMessage());

        List<ApiErrorResponse.ValidationError> validationErrors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(error -> ApiErrorResponse.ValidationError.builder()
                        .field(error.getField())
                        .rejectedValue(error.getRejectedValue())
                        .message(error.getDefaultMessage())
                        .build())
                .toList();

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.VALIDATION_ERROR,
                request,
                traceId
        );
        apiErrorResponse.setValidationErrors(validationErrors);

        return ResponseEntity.badRequest().body(apiErrorResponse);
    }

    // ========== Request Format Exceptions ==========

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiErrorResponse> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Malformed JSON request [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.MALFORMED_JSON,
                request,
                traceId
        );

        return ResponseEntity.badRequest().body(apiErrorResponse);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ApiErrorResponse> handleMissingParameter(MissingServletRequestParameterException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Missing parameter [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.MISSING_PARAMETER,
                request,
                traceId
        );

        // Add specific parameter name to details
        apiErrorResponse.setDetails(String.format("Missing required parameter: %s", ex.getParameterName()));

        return ResponseEntity.badRequest().body(apiErrorResponse);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ApiErrorResponse> handleTypeMismatch(MethodArgumentTypeMismatchException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Type mismatch [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.TYPE_MISMATCH,
                request,
                traceId
        );

        // Add specific type mismatch details
        apiErrorResponse.setDetails(
                String.format(
                        "Parameter '%s' with value '%s' cannot be converted to %s",
                        ex.getName(),
                        ex.getValue(),
                        ex.getRequiredType() != null ? ex.getRequiredType().getSimpleName() : ""));

        return ResponseEntity.badRequest().body(apiErrorResponse);
    }

    // ========== HTTP Method/Resource Exceptions ==========

    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<ApiErrorResponse> handleNoHandlerFound(NoHandlerFoundException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Endpoint not found [{}]: {} {}", traceId, ex.getHttpMethod(), ex.getRequestURL());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.ENDPOINT_NOT_FOUND,
                request,
                traceId
        );

        apiErrorResponse.setDetails(String.format("Endpoint %s %s does not exist",
                ex.getHttpMethod(), ex.getRequestURL()));

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiErrorResponse);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiErrorResponse> handleMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Method not supported [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.METHOD_NOT_ALLOWED,
                request,
                traceId
        );

        String[] supportedMethods = ex.getSupportedMethods();
        String supported = (supportedMethods != null && supportedMethods.length > 0)
                ? String.join(", ", supportedMethods)
                : "";

        String message = String.format("Method '%s' not supported. Supported methods: %s", ex.getMethod(), supported);
        apiErrorResponse.setDetails(message);

        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(apiErrorResponse);
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ApiErrorResponse> handleUnsupportedMediaType(HttpMediaTypeNotSupportedException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Unsupported media type [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.UNSUPPORTED_MEDIA_TYPE,
                request,
                traceId
        );

        apiErrorResponse.setDetails(String.format("Content-Type '%s' is not supported",
                ex.getContentType()));

        return ResponseEntity.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).body(apiErrorResponse);
    }

    // ========== Security Exceptions ==========

    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ApiErrorResponse> handleBadCredentials(BadCredentialsException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Bad credentials [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.BAD_CREDENTIALS,
                request,
                traceId
        );

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(apiErrorResponse);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiErrorResponse> handleAccessDenied(AccessDeniedException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.warn("Access denied [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.FORBIDDEN,
                request,
                traceId
        );

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(apiErrorResponse);
    }

    // ========== Database Exceptions ==========

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiErrorResponse> handleDataIntegrityViolation(DataIntegrityViolationException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.error("Data integrity violation [{}]: {}", traceId, ex.getMessage());

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.DATA_INTEGRITY_VIOLATION,
                request,
                traceId
        );

        return ResponseEntity.status(HttpStatus.CONFLICT).body(apiErrorResponse);
    }

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<ApiErrorResponse> handleDataAccessException(DataAccessException ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.error("Database error [{}]: {}", traceId, ex.getMessage(), ex);

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.DATABASE_ERROR,
                request,
                traceId
        );

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(apiErrorResponse);
    }

    // ========== Generic Exception Fallback ==========

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrorResponse> handleGenericException(Exception ex, HttpServletRequest request) {
        String traceId = generateTraceId();
        log.error("Unexpected error [{}]: {}", traceId, ex.getMessage(), ex);

        ApiErrorResponse apiErrorResponse = createApiErrorResponse(
                ErrorCode.INTERNAL_SERVER_ERROR,
                request,
                traceId
        );

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(apiErrorResponse);
    }

    // ========== Helper Methods ==========

    private ApiErrorResponse createApiErrorResponse(ErrorCode errorCode, HttpServletRequest request, String traceId) {
        return ApiErrorResponse.builder()
                .errorCode(errorCode.getCode())
                .message(errorCode.getMessage())
                .details(errorCode.getDetails())
                .path(request.getRequestURI())
                .method(request.getMethod())
                .timestamp(LocalDateTime.now())
                .traceId(traceId)
                .build();
    }

    private String generateTraceId() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    private String getFieldName(ConstraintViolation<?> violation) {
        Path propertyPath = violation.getPropertyPath();
        String fieldName = null;
        for (Path.Node node : propertyPath) {
            if (node.getName() != null) {
                fieldName = node.getName();
            }
        }
        return fieldName != null ? fieldName : "unknown";
    }
}
